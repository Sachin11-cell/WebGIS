var store={
    "type": "FeatureCollection",
    "features": [
        {
            "type": "Feature",
            "properties": {
                "Name ": "Hamro Thrift Store",
                "Store_hours": "9am-5pm",
                "Contact": 9825066666
            },
            "geometry": {
                "coordinates": [
                    84.0109273903397,
                    28.19225384052183
                ],
                "type": "Point"
            },
            "id": 0
        },
        {
            "type": "Feature",
            "properties": {
                "Name": "Hamro Thrift Store ",
                "Store_hours": "9am-5pm",
                "Contact": 9788489387
            },
            "geometry": {
                "coordinates": [
                    83.99692501766191,
                    28.22679070497783
                ],
                "type": "Point"
            },
            "id": 1
        },
        {
            "type": "Feature",
            "properties": {
                "Name ": "Hamro Thrift Store ",
                "Store_hours ": "9am-5pm",
                "Contact": 9856036696
            },
            "geometry": {
                "coordinates": [
                    83.95869585918388,
                    28.21342281986766
                ],
                "type": "Point"
            },
            "id": 2
        },
        {
            "type": "Feature",
            "properties": {
                "Name": "Hamro Thrift Store",
                "Store_hours": "9am-5pm",
                "Contact": 9800056780
            },
            "geometry": {
                "coordinates": [
                    83.95813003153864,
                    28.19007218931398
                ],
                "type": "Point"
            },
            "id": 3
        },
        {
            "type": "Feature",
            "properties": {
                "Name": "Hamro Thrift Store",
                "Store_hours": "9am-5pm",
                "Contact": 9890056790
            },
            "geometry": {
                "coordinates": [
                    83.98787504314487,
                    28.22434435303913
                ],
                "type": "Point"
            },
            "id": 4
        }
    ]
}