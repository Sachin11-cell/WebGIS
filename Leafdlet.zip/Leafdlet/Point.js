var point={
    "type": "FeatureCollection",
    "features": [
      {
        "type": "Feature",
        "properties": {
          "store": "Hamro Thrift Store",
          "address": "Kathmandu",
        },
        "geometry": {
          "coordinates": [
            85.33647892721973,
            27.700027300982768
          ],
          "type": "Point"
        },
        "id": 0
      },
      {
        "type": "Feature",
        "properties": {
          "store": "Hamro Thrift Store",
          "address": "Butwal",
        },
        "geometry": {
          "coordinates": [
            83.46930218602108,
            27.690254459350285
          ],
          "type": "Point"
        },
        "id": 1
      },
      {
        "type": "Feature",
        "properties": {
          "store": "Hamro Thrift Store",
          "address": "Dhangadhi",
        },
        "geometry": {
          "coordinates": [
            80.56689255446662,
            28.702889189504205
          ],
          "type": "Point"
        },
        "id": 2
      },
      {
        "type": "Feature",
        "properties": {
          "store": "Hamro Thrift Store",
          "address": "Dharan",
        },
        "geometry": {
          "coordinates": [
            87.28459205190927,
            26.812103438622103
          ],
          "type": "Point"
        },
        "id": 3
      }
    ]
  }